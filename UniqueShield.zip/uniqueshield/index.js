const { Client, Collection, GatewayIntentBits, ActivityType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('./config.json');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.commands = new Collection();

// Load commands
const commandFiles = fs.readdirSync(path.join(__dirname, 'commands')).filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
    const command = require(path.join(__dirname, 'commands', file));
    client.commands.set(command.data.name, command);
}

// Load event handlers
const eventHandler = require('./handler/eventHandler');
eventHandler(client);

// Load command handler
const commandHandler = require('./handler/commandHandler');
commandHandler(client);

client.once('ready', async () => {
    console.log(`${client.user.tag} Is Ready`)

    // Bot Status
    const activities = [
        `Over 17131 GUILDS 🌐`,
        `Over 738732 USERS 📱`,
        `Slash Commands`,
        `3724 Global Bans 🚫`,
        `989 Realms 🌌`,
        `14772 Servers 💻`,
        `2841 Accounts Linked 🧑`

    ];

    const activityTypes = [
        ActivityType.Watching,
        ActivityType.Playing,
        ActivityType.Listening,
    ];

    async function pickPresence() {
        const status = activities[Math.floor(Math.random() * activities.length)];
        const type = activityTypes[Math.floor(Math.random() * activityTypes.length)];
        try {
            await client.user.setPresence({
                activities: [
                    {
                        name: status,
                        type: type,
                    },
                ],
                status: 'online'
            });
            console.log(`Presence set to: ${type} ${status}`);
        } catch (error) {
            console.error('Error setting presence:', error);
        }
    }

    // Set the presence immediately upon startup
    await pickPresence();

    // Update presence every 12 seconds
    setInterval(pickPresence, 12000);
});

client.login(config.token);
