const { SlashCommandBuilder } = require('@discordjs/builders');
const { Collection } = require('discord.js');

const cooldowns = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('joinrealm')
        .setDescription('Connect UniqueShield to a Realm(s)'),

    async execute(interaction) {
        const { commandName } = interaction;

        if (interaction.user.id !== interaction.guild.ownerId) {
            await interaction.reply({ content: 'You are not the owner of the guild.', ephemeral: true});
            return; 
        }    

        const cooldownAmount = 5;

        if (!cooldowns.has(commandName)) {
            cooldowns.set(commandName, new Collection());
        }

        const now = Date.now();
        const timestamps = cooldowns.get(commandName);
        const cooldownTime = (cooldownAmount || 3) * 1000;

        if (timestamps.has(interaction.user.id)) {
            const expirationTime = timestamps.get(interaction.user.id) + cooldownTime;

            if (now < expirationTime) {
                const timeLeft = (expirationTime - now) / 1000;
                await interaction.reply({ content: `Please wait ${timeLeft.toFixed(1)} more seconds before reusing the \`${commandName}\` command.`, ephemeral: true});
                return;
            }
        }

        timestamps.set(interaction.user.id, now);
        setTimeout(() => timestamps.delete(interaction.user.id), cooldownTime);

        await interaction.reply({
            embeds: [{
                color: 0x05C62E,
                description: '**Joining the realm... <a:loading:1242713444843655179>**',
            }],
        });

        const responses = [
            {
                author: { name: `${interaction.guild.name}'s Realm` },
                description: '**<a:connected:1242713655124951040> The bot has been joined to the realm**',
                color: 0x05C62E,
            },
            {
                author: { name: `${interaction.guild.name}'s Realm` },
                description: '**<a:disconnected:1242713619762774017> The bot didn\'t join the realm properly! Please rerun the command again.**',
                color: 0xF00909,
            }
        ];

        setTimeout(async () => {
            const randomResponse = responses[Math.floor(Math.random() * responses.length)];
            await interaction.editReply({
                embeds: [randomResponse]
            });
        }, 5000);
    }
};
