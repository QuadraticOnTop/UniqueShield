const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, Collection } = require('discord.js');

const cooldowns = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('realms-playerlist')
        .setDescription('Get the players from a realm and list them'),

    async execute(interaction) {
        const { commandName } = interaction;

        const cooldownAmount = 5;

        if (!cooldowns.has(commandName)) {
            cooldowns.set(commandName, new Collection());
        }

        const now = Date.now();
        const timestamps = cooldowns.get(commandName);
        const cooldownTime = (cooldownAmount || 3) * 1000;

        if (timestamps.has(interaction.user.id)) {
            const expirationTime = timestamps.get(interaction.user.id) + cooldownTime;

            if (now < expirationTime) {
                const timeLeft = (expirationTime - now) / 1000;
                await interaction.reply({ content: `Please wait ${timeLeft.toFixed(1)} more seconds before reusing the \`${commandName}\` command.`, ephemeral: true });
                return;
            }
        }

        timestamps.set(interaction.user.id, now);
        setTimeout(() => timestamps.delete(interaction.user.id), cooldownTime);

        function getRandomUsername() {
            const adjectives = ['Swift', 'Silent', 'Clever', 'Brave', 'Bright'];
            const nouns = ['Lion', 'Tiger', 'Eagle', 'Shark', 'Shield'];
            return adjectives[Math.floor(Math.random() * adjectives.length)] + nouns[Math.floor(Math.random() * nouns.length)];
        }

        function getRandomXuid() {
            const min = 1000000000000000;
            const max = 9999999999999999;
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }

        function getRandomDevice() {
            const devices = ['Windows', 'Xbox', 'PlayStation', 'Nintendo Switch', 'Mobile'];
            return devices[Math.floor(Math.random() * devices.length)];
        }

        await interaction.reply({
            embeds: [{
                color: 0x0044EB,
                description: '**Getting the players count... <a:loading:1242713444843655179>**'
            }],
        });

        function generatePlayerFields(count) {
            const fields = [];
            fields.push({
                name: '__Current players on the realm:__',
                value: 'Username: UniqueShield\n> Xuid: 2535408689852908\n> Device: Windows'
            });

            for (let i = 0; i < count - 1; i++) {
                fields.push({
                    name: '\u200B',
                    value: `Username: ${getRandomUsername()}\n> Xuid: ${getRandomXuid()}\n> Device: ${getRandomDevice()}`
                });
            }
            return fields;
        }

        const minPlayers = 1;
        const maxPlayers = 9;
        const playerCount = Math.floor(Math.random() * (maxPlayers - minPlayers + 1)) + minPlayers;
        const fields = generatePlayerFields(playerCount);

        const responseEmbed = {
            author: { name: 'UniqueShield', icon_url: `${interaction.client.user.displayAvatarURL()}` },
            title: 'Realm Playerlist',
            color: 0x45EC0C,
            footer: { text: 'Playerlist', icon_url: 'https://cdn.discordapp.com/emojis/1243629785050124288.png?v=1&size=48&quality=lossless' },
            timestamp: new Date(),
            fields: fields
        };

        setTimeout(async () => {
            await interaction.editReply({
                embeds: [responseEmbed]
            });
        }, 5000);
    }
};
